(()=>{var a={};a.id=1604,a.ids=[1604],a.modules={261:a=>{"use strict";a.exports=require("next/dist/shared/lib/router/utils/app-paths")},3295:a=>{"use strict";a.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},5559:(a,b,c)=>{"use strict";c.r(b),c.d(b,{handler:()=>D,patchFetch:()=>C,routeModule:()=>y,serverHooks:()=>B,workAsyncStorage:()=>z,workUnitAsyncStorage:()=>A});var d={};c.r(d),c.d(d,{POST:()=>x});var e=c(57867),f=c(70004),g=c(17515),h=c(13283),i=c(74693),j=c(261),k=c(59399),l=c(51273),m=c(36419),n=c(63152),o=c(57326),p=c(5652),q=c(91694),r=c(22187),s=c(86439),t=c(69065),u=c(99642),v=c(81635),w=c(89966);async function x(a){try{let b,{type:c,to:d,variables:e,reminderTime:f,reviewToken:g,customSubject:h,customContent:i,customHtml:j}=await a.json();if(!d||!c)return u.NextResponse.json({error:'Les param\xe8tres "to" et "type" sont requis'},{status:400});let k=Array.isArray(d)?d:[d],l=k.filter(a=>!(0,v.B9)(a));if(l.length>0)return u.NextResponse.json({error:`Emails invalides: ${l.join(", ")}`},{status:400});switch(c){case"welcome":if(!e?.user)return u.NextResponse.json({error:"Les donn\xe9es utilisateur sont requises pour le mail de bienvenue"},{status:400});b=(0,w.fl)(e);break;case"course_assignment":if(!e?.user||!e?.course)return u.NextResponse.json({error:"Les donn\xe9es utilisateur et course sont requises pour l'assignation"},{status:400});b=(0,w.nx)(e);break;case"course_reminder":if(!e?.user||!e?.course||!f)return u.NextResponse.json({error:"Les donn\xe9es utilisateur, course et reminderTime sont requises pour le rappel"},{status:400});b=(0,w.mP)(e,f);break;case"course_completed":if(!e?.user||!e?.course)return u.NextResponse.json({error:"Les donn\xe9es utilisateur et course sont requises pour la confirmation"},{status:400});b=(0,w.dQ)(e);break;case"course_cancelled":if(!e?.user||!e?.course)return u.NextResponse.json({error:"Les donn\xe9es utilisateur et course sont requises pour l'annulation"},{status:400});b=(0,w.Rb)(e);break;case"client_review_reminder":if(!e||!g)return u.NextResponse.json({error:"Les variables et le token de review sont requis pour le rappel d'avis"},{status:400});b=(0,w.W2)(e,g);break;case"client_course_completed_with_review":if(!e||!g)return u.NextResponse.json({error:"Les variables et le token de review sont requis pour le mail de fin de course"},{status:400});b=(0,w.ay)(e,g);break;case"client_driver_assigned":if(!e)return u.NextResponse.json({error:"Les variables sont requises pour l'assignation de chauffeur"},{status:400});b=(0,w.ec)(e);break;case"custom":if(!h||!i&&!j)return u.NextResponse.json({error:"Subject et contenu (text ou HTML) sont requis pour un mail personnalis\xe9"},{status:400});b={subject:h,text:i,html:j};break;default:return u.NextResponse.json({error:`Type de mail non support\xe9: ${c}`},{status:400})}if(!await (0,v.sj)({to:k,subject:b.subject,text:b.text,html:b.html}))return u.NextResponse.json({error:"\xc9chec de l'envoi de l'email"},{status:500});try{await fetch(`${process.env.NEXTAUTH_URL||""}/api/mail/logs`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({type:c,to_emails:k,subject:b.subject,status:"sent",user_id:e?.user?.email||null,course_id:e?.course?.id||null})})}catch(a){console.error("Erreur lors du log dans Supabase:",a)}return u.NextResponse.json({message:"Email envoy\xe9 avec succ\xe8s",to:k,subject:b.subject})}catch(b){console.error("Erreur lors de l'envoi de l'email:",b);try{let c=await a.json();await fetch(`${process.env.NEXTAUTH_URL||""}/api/mail/logs`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({type:c.type,to_emails:Array.isArray(c.to)?c.to:[c.to],subject:c.customSubject||"Erreur d'envoi",status:"failed",error_message:b instanceof Error?b.message:"Erreur inconnue",user_id:c.variables?.user?.email||null,course_id:c.variables?.course?.id||null})})}catch(a){console.error("Erreur lors du log d'erreur dans Supabase:",a)}return u.NextResponse.json({error:"Erreur interne du serveur"},{status:500})}}let y=new e.AppRouteRouteModule({definition:{kind:f.RouteKind.APP_ROUTE,page:"/api/mail/send/route",pathname:"/api/mail/send",filename:"route",bundlePath:"app/api/mail/send/route"},distDir:".next",projectDir:"",resolvedPagePath:"/Users/olivier/Documents/Hub FD/05. Dev/Docker/willy/taxi-manager/src/app/api/mail/send/route.ts",nextConfigOutput:"",userland:d}),{workAsyncStorage:z,workUnitAsyncStorage:A,serverHooks:B}=y;function C(){return(0,g.patchFetch)({workAsyncStorage:z,workUnitAsyncStorage:A})}async function D(a,b,c){var d;let e="/api/mail/send/route";"/index"===e&&(e="/");let g=await y.prepare(a,b,{srcPage:e,multiZoneDraftMode:"false"});if(!g)return b.statusCode=400,b.end("Bad Request"),null==c.waitUntil||c.waitUntil.call(c,Promise.resolve()),null;let{buildId:u,params:v,nextConfig:w,isDraftMode:x,prerenderManifest:z,routerServerContext:A,isOnDemandRevalidate:B,revalidateOnlyGenerated:C,resolvedPathname:D}=g,E=(0,j.normalizeAppPath)(e),F=!!(z.dynamicRoutes[E]||z.routes[D]);if(F&&!x){let a=!!z.routes[D],b=z.dynamicRoutes[E];if(b&&!1===b.fallback&&!a)throw new s.NoFallbackError}let G=null;!F||y.isDev||x||(G="/index"===(G=D)?"/":G);let H=!0===y.isDev||!F,I=F&&!H,J=a.method||"GET",K=(0,i.getTracer)(),L=K.getActiveScopeSpan(),M={params:v,prerenderManifest:z,renderOpts:{experimental:{dynamicIO:!!w.experimental.dynamicIO,authInterrupts:!!w.experimental.authInterrupts},supportsDynamicResponse:H,incrementalCache:(0,h.getRequestMeta)(a,"incrementalCache"),cacheLifeProfiles:null==(d=w.experimental)?void 0:d.cacheLife,isRevalidate:I,waitUntil:c.waitUntil,onClose:a=>{b.on("close",a)},onAfterTaskError:void 0,onInstrumentationRequestError:(b,c,d)=>y.onRequestError(a,b,d,A)},sharedContext:{buildId:u}},N=new k.NodeNextRequest(a),O=new k.NodeNextResponse(b),P=l.NextRequestAdapter.fromNodeNextRequest(N,(0,l.signalFromNodeResponse)(b));try{let d=async c=>y.handle(P,M).finally(()=>{if(!c)return;c.setAttributes({"http.status_code":b.statusCode,"next.rsc":!1});let d=K.getRootSpanAttributes();if(!d)return;if(d.get("next.span_type")!==m.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${d.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let e=d.get("next.route");if(e){let a=`${J} ${e}`;c.setAttributes({"next.route":e,"http.route":e,"next.span_name":a}),c.updateName(a)}else c.updateName(`${J} ${a.url}`)}),g=async g=>{var i,j;let k=async({previousCacheEntry:f})=>{try{if(!(0,h.getRequestMeta)(a,"minimalMode")&&B&&C&&!f)return b.statusCode=404,b.setHeader("x-nextjs-cache","REVALIDATED"),b.end("This page could not be found"),null;let e=await d(g);a.fetchMetrics=M.renderOpts.fetchMetrics;let i=M.renderOpts.pendingWaitUntil;i&&c.waitUntil&&(c.waitUntil(i),i=void 0);let j=M.renderOpts.collectedTags;if(!F)return await (0,o.I)(N,O,e,M.renderOpts.pendingWaitUntil),null;{let a=await e.blob(),b=(0,p.toNodeOutgoingHttpHeaders)(e.headers);j&&(b[r.NEXT_CACHE_TAGS_HEADER]=j),!b["content-type"]&&a.type&&(b["content-type"]=a.type);let c=void 0!==M.renderOpts.collectedRevalidate&&!(M.renderOpts.collectedRevalidate>=r.INFINITE_CACHE)&&M.renderOpts.collectedRevalidate,d=void 0===M.renderOpts.collectedExpire||M.renderOpts.collectedExpire>=r.INFINITE_CACHE?void 0:M.renderOpts.collectedExpire;return{value:{kind:t.CachedRouteKind.APP_ROUTE,status:e.status,body:Buffer.from(await a.arrayBuffer()),headers:b},cacheControl:{revalidate:c,expire:d}}}}catch(b){throw(null==f?void 0:f.isStale)&&await y.onRequestError(a,b,{routerKind:"App Router",routePath:e,routeType:"route",revalidateReason:(0,n.c)({isRevalidate:I,isOnDemandRevalidate:B})},A),b}},l=await y.handleResponse({req:a,nextConfig:w,cacheKey:G,routeKind:f.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:z,isRoutePPREnabled:!1,isOnDemandRevalidate:B,revalidateOnlyGenerated:C,responseGenerator:k,waitUntil:c.waitUntil});if(!F)return null;if((null==l||null==(i=l.value)?void 0:i.kind)!==t.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==l||null==(j=l.value)?void 0:j.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});(0,h.getRequestMeta)(a,"minimalMode")||b.setHeader("x-nextjs-cache",B?"REVALIDATED":l.isMiss?"MISS":l.isStale?"STALE":"HIT"),x&&b.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let m=(0,p.fromNodeOutgoingHttpHeaders)(l.value.headers);return(0,h.getRequestMeta)(a,"minimalMode")&&F||m.delete(r.NEXT_CACHE_TAGS_HEADER),!l.cacheControl||b.getHeader("Cache-Control")||m.get("Cache-Control")||m.set("Cache-Control",(0,q.getCacheControlHeader)(l.cacheControl)),await (0,o.I)(N,O,new Response(l.value.body,{headers:m,status:l.value.status||200})),null};L?await g(L):await K.withPropagatedContext(a.headers,()=>K.trace(m.BaseServerSpan.handleRequest,{spanName:`${J} ${a.url}`,kind:i.SpanKind.SERVER,attributes:{"http.method":J,"http.target":a.url}},g))}catch(b){if(L||b instanceof s.NoFallbackError||await y.onRequestError(a,b,{routerKind:"App Router",routePath:E,routeType:"route",revalidateReason:(0,n.c)({isRevalidate:I,isOnDemandRevalidate:B})}),F)throw b;return await (0,o.I)(N,O,new Response(null,{status:500})),null}}},10846:a=>{"use strict";a.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},14985:a=>{"use strict";a.exports=require("dns")},21820:a=>{"use strict";a.exports=require("os")},24247:()=>{},27910:a=>{"use strict";a.exports=require("stream")},28354:a=>{"use strict";a.exports=require("util")},29021:a=>{"use strict";a.exports=require("fs")},29294:a=>{"use strict";a.exports=require("next/dist/server/app-render/work-async-storage.external.js")},33873:a=>{"use strict";a.exports=require("path")},34631:a=>{"use strict";a.exports=require("tls")},44870:a=>{"use strict";a.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},55511:a=>{"use strict";a.exports=require("crypto")},55591:a=>{"use strict";a.exports=require("https")},63033:a=>{"use strict";a.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},74075:a=>{"use strict";a.exports=require("zlib")},79551:a=>{"use strict";a.exports=require("url")},79646:a=>{"use strict";a.exports=require("child_process")},81630:a=>{"use strict";a.exports=require("http")},81635:(a,b,c)=>{"use strict";c.d(b,{B9:()=>h,I$:()=>f,sj:()=>g});var d=c(60236);let e=()=>d.createTransport({host:process.env.SMTP_HOST||"smtp.titan.email",port:parseInt(process.env.SMTP_PORT||"465"),secure:!0,auth:{user:process.env.SMTP_USER,pass:process.env.SMTP_PASS},tls:{rejectUnauthorized:!1}}),f=async()=>{try{let a=e();return await a.verify(),console.log("✅ Connexion SMTP v\xe9rifi\xe9e avec succ\xe8s"),!0}catch(a){return console.error("❌ Erreur de connexion SMTP:",a),!1}},g=async(a,b=3)=>{let c=e(),d={from:`"${process.env.MAIL_FROM_NAME||"Taxi Manager"}" <${process.env.SMTP_USER}>`,...a};for(let a=1;a<=b;a++)try{let a=await c.sendMail(d);return console.log(`📧 Email envoy\xe9 avec succ\xe8s:`,a.messageId),!0}catch(c){if(console.error(`❌ Tentative ${a}/${b} \xe9chou\xe9e:`,c),a===b)return console.error("\uD83D\uDCA5 Tous les essais d'envoi ont \xe9chou\xe9"),!1;await new Promise(b=>setTimeout(b,1e3*Math.pow(2,a)))}return!1},h=a=>/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(a)},86439:a=>{"use strict";a.exports=require("next/dist/shared/lib/no-fallback-error.external")},87295:()=>{},89966:(a,b,c)=>{"use strict";c.d(b,{Rb:()=>i,W2:()=>l,ay:()=>k,dQ:()=>h,ec:()=>j,fl:()=>e,mP:()=>g,nx:()=>f});let d=(a,b)=>`
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${b}</title>
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f8fafc;
        }
        .container {
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .header {
            text-align: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 2px solid #fbbf24;
        }
        .logo {
            font-size: 24px;
            font-weight: bold;
            color: #f59e0b;
            margin-bottom: 10px;
        }
        .title {
            color: #1f2937;
            font-size: 20px;
            margin-bottom: 20px;
        }
        .content {
            margin-bottom: 30px;
        }
        .button {
            display: inline-block;
            background: #f59e0b;
            color: white !important;
            text-decoration: none;
            padding: 12px 24px;
            border-radius: 6px;
            font-weight: 500;
            margin: 15px 0;
        }
        .info-box {
            background: #f3f4f6;
            padding: 20px;
            border-radius: 8px;
            margin: 15px 0;
        }
        .footer {
            text-align: center;
            color: #6b7280;
            font-size: 14px;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #e5e7eb;
        }
        .urgent {
            background: #fef2f2;
            border-left: 4px solid #ef4444;
            padding: 15px;
            margin: 15px 0;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="logo">🚕 Taxi Manager</div>
            <h1 class="title">${b}</h1>
        </div>
        <div class="content">
            ${a}
        </div>
        <div class="footer">
            <p>Ceci est un email automatique, merci de ne pas r\xe9pondre.</p>
            <p>\xa9 2025 Taxi Manager - Tous droits r\xe9serv\xe9s</p>
        </div>
    </div>
</body>
</html>
`,e=a=>{let{user:b,companyName:c="Taxi Manager",loginUrl:e=process.env.NEXTAUTH_URL}=a,f=`
    <p>Bonjour <strong>${b?.prenom} ${b?.nom}</strong>,</p>
    
    <p>Bienvenue dans ${c} ! Votre compte a \xe9t\xe9 cr\xe9\xe9 avec succ\xe8s.</p>
    
    <div class="info-box">
        <h3>Informations de votre compte :</h3>
        <p><strong>Email :</strong> ${b?.email}</p>
        <p><strong>R\xf4le :</strong> ${b?.role}</p>
        <p><strong>Statut :</strong> Actif</p>
    </div>
    
    <p>Vous pouvez maintenant acc\xe9der \xe0 l'application en utilisant le lien ci-dessous :</p>
    
    <p style="text-align: center;">
        <a href="${e}" class="button">Acc\xe9der \xe0 l'application</a>
    </p>
    
    <p>Utilisez votre adresse email pour vous connecter. Un mot de passe temporaire vous sera communiqu\xe9 s\xe9par\xe9ment par votre administrateur.</p>
    
    <p>Si vous avez des questions, n'h\xe9sitez pas \xe0 contacter notre support.</p>
    
    <p>Cordialement,<br>L'\xe9quipe ${c}</p>
  `;return{subject:`Bienvenue dans ${c} !`,html:d(f,"Bienvenue !"),text:`Bonjour ${b?.prenom} ${b?.nom},

Bienvenue dans ${c} ! Votre compte a \xe9t\xe9 cr\xe9\xe9 avec succ\xe8s.

Vous pouvez acc\xe9der \xe0 l'application via : ${e}

Cordialement,
L'\xe9quipe ${c}`}},f=a=>{let{user:b,course:c,companyName:e="Taxi Manager"}=a,f=`
    <p>Bonjour <strong>${b?.prenom} ${b?.nom}</strong>,</p>
    
    <p>Une nouvelle course vous a \xe9t\xe9 assign\xe9e :</p>
    
    <div class="info-box">
        <h3>📍 D\xe9tails de la course</h3>
        <p><strong>Origine :</strong> ${c?.origine}</p>
        <p><strong>Destination :</strong> ${c?.destination}</p>
        <p><strong>Date et heure :</strong> ${c?.dateHeure}</p>
        ${c?.prix?`<p><strong>Prix :</strong> ${c.prix}€</p>`:""}
    </div>
    
    ${c?.client?`
    <div class="info-box">
        <h3>👤 Client</h3>
        <p><strong>Nom :</strong> ${c.client.nom} ${c.client.prenom}</p>
        ${c.client.telephone?`<p><strong>T\xe9l\xe9phone :</strong> ${c.client.telephone}</p>`:""}
    </div>
    `:""}
    
    <p>Merci de vous pr\xe9parer pour cette course et de respecter l'heure de rendez-vous.</p>
    
    <p>Cordialement,<br>L'\xe9quipe ${e}</p>
  `;return{subject:`Nouvelle course assign\xe9e - ${c?.origine} → ${c?.destination}`,html:d(f,"Nouvelle course assign\xe9e"),text:`Bonjour ${b?.prenom} ${b?.nom},

Une nouvelle course vous a \xe9t\xe9 assign\xe9e :

Origine: ${c?.origine}
Destination: ${c?.destination}
Date: ${c?.dateHeure}

Cordialement,
L'\xe9quipe ${e}`}},g=(a,b)=>{let{user:c,course:e,companyName:f="Taxi Manager"}=a,g=`
    <div class="urgent">
        <h3>⏰ Rappel urgent - Course dans ${b}</h3>
    </div>
    
    <p>Bonjour <strong>${c?.prenom} ${c?.nom}</strong>,</p>
    
    <p>Votre course commence dans <strong>${b}</strong> :</p>
    
    <div class="info-box">
        <h3>📍 D\xe9tails de la course</h3>
        <p><strong>Origine :</strong> ${e?.origine}</p>
        <p><strong>Destination :</strong> ${e?.destination}</p>
        <p><strong>Heure de d\xe9part :</strong> ${e?.dateHeure}</p>
    </div>
    
    ${e?.client?`
    <div class="info-box">
        <h3>👤 Client \xe0 contacter</h3>
        <p><strong>Nom :</strong> ${e.client.nom} ${e.client.prenom}</p>
        ${e.client.telephone?`<p><strong>T\xe9l\xe9phone :</strong> <a href="tel:${e.client.telephone}">${e.client.telephone}</a></p>`:""}
    </div>
    `:""}
    
    <p><strong>Merci de vous pr\xe9parer d\xe8s maintenant !</strong></p>
    
    <p>Cordialement,<br>L'\xe9quipe ${f}</p>
  `;return{subject:`🚨 Rappel urgent - Course dans ${b}`,html:d(g,`Rappel - Course dans ${b}`),text:`RAPPEL URGENT - Course dans ${b}

Bonjour ${c?.prenom} ${c?.nom},

Votre course: ${e?.origine} → ${e?.destination}
Heure: ${e?.dateHeure}

Pr\xe9parez-vous d\xe8s maintenant !

Cordialement,
L'\xe9quipe ${f}`}},h=a=>{let{user:b,course:c,companyName:e="Taxi Manager"}=a,f=`
    <p>Bonjour <strong>${b?.prenom} ${b?.nom}</strong>,</p>
    
    <p>✅ Votre course a \xe9t\xe9 marqu\xe9e comme termin\xe9e avec succ\xe8s !</p>
    
    <div class="info-box">
        <h3>📍 R\xe9capitulatif</h3>
        <p><strong>Trajet :</strong> ${c?.origine} → ${c?.destination}</p>
        <p><strong>Date :</strong> ${c?.dateHeure}</p>
        ${c?.prix?`<p><strong>Montant :</strong> ${c.prix}€</p>`:""}
    </div>
    
    <p>Merci pour votre professionnalisme !</p>
    
    <p>Cordialement,<br>L'\xe9quipe ${e}</p>
  `;return{subject:`Course termin\xe9e - ${c?.origine} → ${c?.destination}`,html:d(f,"Course termin\xe9e"),text:`Bonjour ${b?.prenom} ${b?.nom},

Votre course ${c?.origine} → ${c?.destination} a \xe9t\xe9 termin\xe9e avec succ\xe8s !

Merci pour votre professionnalisme.

Cordialement,
L'\xe9quipe ${e}`}},i=a=>{let{user:b,course:c,companyName:e="Taxi Manager"}=a,f=`
    <div class="urgent">
        <h3>❌ Course annul\xe9e</h3>
    </div>
    
    <p>Bonjour <strong>${b?.prenom} ${b?.nom}</strong>,</p>
    
    <p>La course suivante a \xe9t\xe9 <strong>annul\xe9e</strong> :</p>
    
    <div class="info-box">
        <h3>📍 Course annul\xe9e</h3>
        <p><strong>Trajet :</strong> ${c?.origine} → ${c?.destination}</p>
        <p><strong>Date pr\xe9vue :</strong> ${c?.dateHeure}</p>
    </div>
    
    <p>Vous n'avez plus besoin de vous rendre \xe0 cette course. Veuillez consulter votre planning pour vos prochaines assignations.</p>
    
    <p>Cordialement,<br>L'\xe9quipe ${e}</p>
  `;return{subject:`❌ Course annul\xe9e - ${c?.origine} → ${c?.destination}`,html:d(f,"Course annul\xe9e"),text:`COURSE ANNUL\xc9E

Bonjour ${b?.prenom} ${b?.nom},

La course ${c?.origine} → ${c?.destination} pr\xe9vue le ${c?.dateHeure} a \xe9t\xe9 annul\xe9e.

Consultez votre planning pour les prochaines courses.

Cordialement,
L'\xe9quipe ${e}`}},j=a=>{let{course:b,companyName:c="Taxi Manager"}=a,e=`
    <p>Bonjour <strong>${b?.client?.prenom} ${b?.client?.nom}</strong>,</p>
    
    <p>✅ Un chauffeur a \xe9t\xe9 assign\xe9 \xe0 votre course !</p>
    
    <div class="info-box">
        <h3>🚕 Votre chauffeur</h3>
        <p><strong>Nom :</strong> ${b?.user?.prenom} ${b?.user?.nom}</p>
        ${b?.user?.telephone?`<p><strong>T\xe9l\xe9phone :</strong> <a href="tel:${b.user.telephone}">${b.user.telephone}</a></p>`:""}
    </div>
    
    <div class="info-box">
        <h3>📍 Rappel de votre course</h3>
        <p><strong>D\xe9part :</strong> ${b?.origine}</p>
        <p><strong>Arriv\xe9e :</strong> ${b?.destination}</p>
        <p><strong>Date et heure :</strong> ${new Date(b?.dateHeure||"").toLocaleString("fr-FR",{weekday:"long",day:"numeric",month:"long",year:"numeric",hour:"2-digit",minute:"2-digit"})}</p>
    </div>
    
    <p>Votre chauffeur vous contactera si n\xe9cessaire avant la course.</p>
    
    <p>Cordialement,<br>L'\xe9quipe ${c}</p>
  `;return{subject:`Chauffeur assign\xe9 - ${b?.user?.prenom} ${b?.user?.nom}`,html:d(e,"Chauffeur assign\xe9"),text:`Bonjour ${b?.client?.prenom} ${b?.client?.nom},

Un chauffeur a \xe9t\xe9 assign\xe9 :

Chauffeur: ${b?.user?.prenom} ${b?.user?.nom}
${b?.user?.telephone?`T\xe9l\xe9phone: ${b.user.telephone}
`:""}
Course: ${b?.origine} → ${b?.destination}
Date: ${new Date(b?.dateHeure||"").toLocaleString("fr-FR")}

Cordialement,
L'\xe9quipe ${c}`}},k=(a,b)=>{let{course:c,companyName:e="Taxi Manager"}=a,f=`${process.env.NEXTAUTH_URL}/avis/${b}`;return{subject:`Course termin\xe9e - Votre avis nous int\xe9resse ! ⭐`,html:d(`
    <p>Bonjour <strong>${c?.client?.prenom} ${c?.client?.nom}</strong>,</p>
    
    <p>✅ Votre course s'est bien d\xe9roul\xe9e !</p>
    
    <div class="info-box">
        <h3>📍 Course termin\xe9e</h3>
        <p><strong>Trajet :</strong> ${c?.origine} → ${c?.destination}</p>
        <p><strong>Date :</strong> ${new Date(c?.dateHeure||"").toLocaleString("fr-FR")}</p>
        ${c?.user?`<p><strong>Chauffeur :</strong> ${c.user.prenom} ${c.user.nom}</p>`:""}
        ${c?.prix?`<p><strong>Montant :</strong> ${c.prix}€</p>`:""}
    </div>
    
    <p>Nous esp\xe9rons que notre service vous a satisfait !</p>
    
    <div style="text-align: center; margin: 30px 0;">
        <h3>⭐ Donnez votre avis</h3>
        <p>Votre opinion nous aide \xe0 am\xe9liorer notre service.</p>
        <a href="${f}" class="button">Laisser un avis (2 min)</a>
    </div>
    
    <p>Merci de nous avoir fait confiance !</p>
    
    <p>Cordialement,<br>L'\xe9quipe ${e}</p>
  `,"Course termin\xe9e"),text:`Bonjour ${c?.client?.prenom} ${c?.client?.nom},

Votre course ${c?.origine} → ${c?.destination} s'est bien d\xe9roul\xe9e !

Donnez votre avis : ${f}

Merci de nous avoir fait confiance !

Cordialement,
L'\xe9quipe ${e}`}},l=(a,b)=>{let{course:c,companyName:e="Taxi Manager"}=a,f=`${process.env.NEXTAUTH_URL}/avis/${b}`,g=`
    <p>Bonjour <strong>${c?.client?.prenom} ${c?.client?.nom}</strong>,</p>
    
    <p>Vous avez r\xe9cemment utilis\xe9 nos services et nous aimerions beaucoup conna\xeetre votre opinion !</p>
    
    <div class="info-box">
        <h3>📍 Course concern\xe9e</h3>
        <p><strong>Trajet :</strong> ${c?.origine} → ${c?.destination}</p>
        <p><strong>Date :</strong> ${new Date(c?.dateHeure||"").toLocaleDateString("fr-FR")}</p>
        ${c?.user?`<p><strong>Chauffeur :</strong> ${c.user.prenom} ${c.user.nom}</p>`:""}
    </div>
    
    <div style="text-align: center; margin: 30px 0;">
        <h3>⭐ 2 minutes pour nous aider</h3>
        <p>Votre avis nous permet d'am\xe9liorer continuellement notre service.</p>
        <a href="${f}" class="button">Donner mon avis</a>
    </div>
    
    <p><small>Si vous ne souhaitez plus recevoir ces demandes d'avis, <a href="${f}?unsubscribe=true">cliquez ici</a>.</small></p>
    
    <p>Merci pour votre temps !</p>
    
    <p>Cordialement,<br>L'\xe9quipe ${e}</p>
  `;return{subject:`Votre avis nous int\xe9resse - Course du ${new Date(c?.dateHeure||"").toLocaleDateString("fr-FR")} ⭐`,html:d(g,"Donnez votre avis"),text:`Bonjour ${c?.client?.prenom} ${c?.client?.nom},

Votre avis sur la course ${c?.origine} → ${c?.destination} du ${new Date(c?.dateHeure||"").toLocaleDateString("fr-FR")} nous int\xe9resse !

Donnez votre avis : ${f}

Merci !

Cordialement,
L'\xe9quipe ${e}`}}},91645:a=>{"use strict";a.exports=require("net")},94735:a=>{"use strict";a.exports=require("events")}};var b=require("../../../../webpack-runtime.js");b.C(a);var c=b.X(0,[2107,4043,236],()=>b(b.s=5559));module.exports=c})();